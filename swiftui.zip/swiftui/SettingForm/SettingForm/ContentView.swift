//
//  ContentView.swift
//  SettingForm
//
//  Created by Students on 5/3/25.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    @State private var darkModeOn = false
    @State private var volume =  0.1
    @State private var selectedColor = "red"
    let colors = ["red", "blue", "green", "orange", "yellow"]
    var body: some View {
        Form{
            Section {
                TextField("Enter name", text:$username)
                Text(username)
                    .foregroundStyle(.blue) // just checking of values of the variable
                    .font(.caption)
                    .italic()
            }
            
            Toggle("Enable Dark Mode", isOn: $darkModeOn)
            Text("Dark mode is \(darkModeOn ? "on" : "off")")
                .foregroundStyle(.blue)
                .font(.caption)
                .italic()
            
            Section("Volume") {
                Slider(value: $volume, in: 0...1)
                Text("Volume: \(volume * 100) %")
                    .foregroundStyle(.gray)
                    .font(.caption)
                    .italic()
            }
            
            Section("Color") {
                Picker("Select a color", selection: $selectedColor){
                    ForEach(colors, id: \.self) {
                        color in
                        Text(color)
                    }
                }.pickerStyle(.wheel)
            }
        }
    }
}

#Preview {
    ContentView()
}
