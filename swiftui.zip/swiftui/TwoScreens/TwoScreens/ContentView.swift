//
//  ContentView.swift
//  TwoScreens
//
//  Created by Students on 4/3/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
            NavigationView {
                ZStack{ Color.gray.opacity(0.2)
                    VStack {
                        Image(systemName: "house.circle").imageScale(.large).font(.largeTitle)
                        NavigationLink(destination: SecondScreen()) {Text("Go to second screen").padding()
                                .background(Color.orange)
                                .foregroundStyle(.white)
                        }
                        NavigationLink(destination: ThirdScreen()) {Text("Go to third screen").padding()
                                .background(Color.purple)
                                .foregroundStyle(.white)
                        }
                        NavigationLink(destination: CounterStack(counterName: "My Counter")) {Text("Go to Counter").padding()
                                .background(Color.green)
                                .foregroundStyle(.white)
                        }
                        .navigationTitle("Home Screen")
                    }
                }
            }
        }
    }
struct SecondScreen: View {
    var body: some View {
        Text("Second Screen")
            .navigationTitle("Trending page")
    }
                    
}
struct ThirdScreen: View {
    var body: some View {
        Text("Third Screen")
            .navigationTitle("Shopping Page")
    }
                    
}


struct CounterStack: View {
    // create state variable 'count'
    var counterName: String
    @State private var count = 0
    
    @State private var isbuttonDisabled = true
    // create a function that return a colorbased on the value of count
    func getColor(for count: Int) -> Color {
        switch count {
        case 0:
            return .gray
        case Int.min..<0: // less than 0
            return .red
        case 1...5:
            return .green
        case 6...10:
            return .blue
        default:
            return .purple
        }
    }
    
    var body: some View {
        ZStack {
            Color.blue.opacity(0.2)
            
            VStack(spacing : 30) {
                Text("Number: \(count)")
                    .font(.largeTitle)
                    .padding([.top, .bottom], 50)
                    .padding([.leading, .trailing], 30)
                    .foregroundStyle(.white)
                    .background(getColor(for: count))
                HStack (spacing: 30){
                    Button("Decrease") {
                        count -= 1
                    }
                    .padding()
                    .background(Color.red)
                    .foregroundStyle(.white)
                    Button("Increase") {
                        count += 1
                    }
                    .padding()
                    .background(Color.green)
                    .foregroundStyle(.white)
                    
                    
                }
                Button("Reset") {
                    count = 0
                    
                }
                .padding()
                .background(Color.blue)
                .foregroundStyle(.white)
                .disabled(isbuttonDisabled)
                .padding()
                // disable the buttons
                Button("\(isbuttonDisabled ? "Enable" :"Disable") button") {
                    isbuttonDisabled.toggle()
                }
            }
            .navigationTitle("Number Counter")
        }
    }
}

#Preview {
    ContentView()
}
