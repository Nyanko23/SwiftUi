//
//  MyAppApp.swift
//  MyApp
//
//  Created by Students on 3/3/25.
//

import SwiftUI

@main
struct MyAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
