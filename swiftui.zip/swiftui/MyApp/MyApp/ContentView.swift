//
//  ContentView.swift
//  MyApp
//
//  Created by Students on 3/3/25.
//

import SwiftUI

struct ContentView: View {
    let greeting = "Hello, everyone!"
    var welcomeImage = "bird"
   
    
    var body: some View {
        HStack { //horiontal stack, arranges views in a row
            Image(systemName: welcomeImage) // image modifier to scale the image size
                .imageScale(.large)
                .foregroundStyle(.purple)
            Text(greeting)
        }
        .padding()
        VStack { // vertical stack
            Text("This is my first swift app!") // this is the text, color, bold, and sizes of the text
                .foregroundStyle(.orange)
                .bold()
                .font(.title2)
        }
    }
}

#Preview {
    ContentView()
}
