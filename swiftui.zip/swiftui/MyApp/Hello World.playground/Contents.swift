import UIKit

// let is constant value cannot be change
// var values can be change

greeting = "Hello, World"
print("Hello, World")

var greeting = "Hello, playground"
var greeting2 = "Goodbye"

greeting2 = "Goodbye, playground"
print(greeting)

// shortcut for comment is commend + /
let pi = 3.14
var savings = 200

struct Person {
    let firstName: String // type annotations, properties
    let lastName: String
    
    func sayHello() { // this is a function or method
        print("Hello there! My name is \(firstName) \(lastName).")
    }
}
// string interpolation
var name = "Ariel"
let welocomeMsg = "Hello, \(name)!"
print(welocomeMsg)

//day 2 switch statement alternative of if else statement
var timeElapsed = 125
var unit: String
switch timeElapsed {
case 0...1 :
    unit = "second"
case 2...59:
    unit = "seconds"
case 60...119:
    unit = "minute"
    timeElapsed = timeElapsed/60
default:
    unit = "minutes"
    timeElapsed /= 60
}
print("\(timeElapsed) \(unit)")

let temperature = 70 // using if else
if temperature >= 65 && temperature <= 75 {
    print("the tempature is just right.")
} else {
    if temperature < 65 {
        print("its too cold")
    } else {
        print("its too hot")
    }
}

// Ternary operator (?:) --> condition ? true value: false value
var largest: Int
let a = 15
let b = 4

largest = a != b ? a:b // if a is largest than b value, will assign largest with a values
print(largest)

let marks = 60

// use of ternary operator
let result = (marks >= 40) ? "pass" : "fail"

print("You " + result + " the exam")


var happinesslevel = 6

let message = happinesslevel > 5 ? "🥳!": "🙁!"

print(message)

// state variable --> tells swfutui to monitor changes in a variable
// @state

// Navigation, multi-view applications and looping
// arrays
var names: [String] = ["Alice", "Jay", "Caden"]

print(names[2])
// names[0] = "Angel"

let secondname = "Ms. " + names[0]
print(secondname)
names.append("Aries")
print(names)

print(names.count)

// looping for example each name
names.forEach {
    num in
    print(num)
}

let number = [1,2,3,4]
number.forEach {
    x in
    print(x + 1)
}
// navigation to allow users to move between different screens
// uses NavigationView and NavigationLink

//struct ContentView: View {
//    var body: some View {
//        NavigationView {
//            NavigationLink("Go....", destination: DetailView())
//        }
//    }
//}
// day 3

// define email validating function
print("day 3")

func isEmailValid(_ email: String) -> Bool {
    print("email string contains '@': \(email.contains("@"))")
    print("email string contains '.': \(email.contains("."))")
    print("email is valid: \(email.contains("@") && email.contains("."))".uppercased())
    return email.contains("@") && email.contains(".")
}

// call out the function
isEmailValid("myemailaddress")
isEmailValid("myemail@address.com")
