//
//  ContentView.swift
//  ListofItems
//
//  Created by Students on 4/3/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        let items:[String] = ["Tea", "Fish", "Risotto", "Potato", "Ice cream", "Tacos", "Sushi", "Pancakes", "Cake", "Bread"]
        //v1 : manual list
        List {
            HStack {
                Image(systemName: "takeoutbag.and.cup.and.straw.fill").font(.largeTitle).foregroundStyle(Color.red)
                Text("Burger")
            }
            Text("Steak")
            Text("Pasta")
        }
        .frame(height:200)
        // v2 : dynamic list
        List(items, id: \.self) {item in
            Text(item.uppercased())
        }
        // v3: list with navigation
        NavigationView {
            List(items, id: \.self) {item in
                NavigationLink(destination: RecipeScreen(itemName: item)){
                    Text("see recipe for \(item)")
                }
            }
        }
    }
}
struct RecipeScreen: View {
    let itemName:String
    var body:some View {
        Text("Recipe for \(itemName)").font(.largeTitle)
    }
}

#Preview {
    ContentView()
}
