//
//  ListofItemsApp.swift
//  ListofItems
//
//  Created by Students on 4/3/25.
//

import SwiftUI

@main
struct ListofItemsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
