//
//  HelloWorldApp.swift
//  HelloWorld
//
//  Created by Students on 3/3/25.
//

import SwiftUI

@main
struct HelloWorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
