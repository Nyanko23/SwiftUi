//
//  ContentView.swift
//  HelloWorld
//
//  Created by Students on 3/3/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        var timeElapsed = 15
        var unit: String
        var timestamp: String
        
        if timeElapsed >= 60 {
            unit = "minute"
            if timeElapsed >= 120 {
                unit = "minutes"
            }
            timeElapsed = timeElapsed / 60
        } else {
            if timeElapsed > 1 {
                unit = "seconds"
            } else {
                unit = "second"
            }
        }
        timestamp = "Sent \(timeElapsed) \(unit) ago"
        
        return HStack {
            ZStack {
                Color.cyan.frame(width:80, height:80).opacity(0.5)
                Image(systemName: "bird")
                    .imageScale(.large)
                .foregroundStyle(.red)
            }
            Spacer()
            Text("Hello, world!")
                .padding() // add spacing
                .background(Color.yellow)
            Text(timestamp)
                .italic()
                .foregroundStyle(Color.gray)
            Image(systemName: "moon.stars") // another image
                .imageScale(.large)
                .foregroundStyle(.black)
                .aspectRatio(/*@START_MENU_TOKEN@*/1.5/*@END_MENU_TOKEN@*/, contentMode: .fill)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
