//
//  ContentView.swift
//  CounterApp
//
//  Created by Students on 4/3/25.
//

import SwiftUI
struct ContentView: View {
    // create state variable 'count'
    @State private var count = 0
    
    @State private var isbuttonDisabled = true
    // create a function that return a colorbased on the value of count
    func getColor(for count: Int) -> Color {
        switch count {
        case 0:
            return .gray
        case Int.min..<0: // less than 0
            return .red
        case 1...5:
            return .green
        case 6...10:
            return .blue
        default:
            return .purple
        }
    }
    
    var body: some View {
        ZStack {
            Color.blue.opacity(0.2)
            
            VStack(spacing : 30) {
                Text("Counter: \(count)")
                    .font(.largeTitle)
                    .padding([.top, .bottom], 50)
                    .padding([.leading, .trailing], 30)
                    .foregroundStyle(.white)
                    .background(getColor(for: count))
                HStack (spacing: 30){
                    Button("Decrease") {
                        count -= 1
                    }
                    .padding()
                    .background(Color.red)
                    .foregroundStyle(.white)
                    Button("Increase") {
                        count += 1
                    }
                    .padding()
                    .background(Color.green)
                    .foregroundStyle(.white)
                    
                    
                }
                Button("Reset") {
                    count = 0
                    
                }
                .padding()
                .background(Color.blue)
                .foregroundStyle(.white)
                .disabled(isbuttonDisabled)
                .padding()
                // disable the buttons
                Button("\(isbuttonDisabled ? "Enable" :"Disable") button") {
                    isbuttonDisabled.toggle()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
