//
//  CounterAppApp.swift
//  CounterApp
//
//  Created by Students on 4/3/25.
//

import SwiftUI

@main
struct CounterAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
