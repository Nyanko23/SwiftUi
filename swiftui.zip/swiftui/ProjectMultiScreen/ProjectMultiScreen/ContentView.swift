//
//  ContentView.swift
//  ProjectMultiScreen
//
//  Created by Students on 5/3/25.
//

import SwiftUI

// Content View for the Home screen
struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Create the pink gradient background
            LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]),
                           startPoint: .top,
                           endPoint: .bottom)
            .edgesIgnoringSafeArea(.all)
            VStack {
                // Background image
                Image("cat")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 200, height: 300)
                    .padding(.top, 30)
                    
                    //home page
                    HomeScreen()
                    
                    VStack(spacing: 10) {
                        // Navigation Link to go to the List screen
                        NavigationLink(destination: ListScreen())
                        {
                            Text("Go to the next page")
                                .padding(10)
                                .font(.title2)
                                .background(Color.purple)
                                .foregroundStyle(.white)
                                .cornerRadius(10)
                        }
                        .padding(.bottom, 10)
                        NavigationLink(destination: ClickTracker()) {
                            Text("Go to counter")
                                .padding(10)
                                .font(.title2)
                                .background(Color.green)
                                .foregroundStyle(.white)
                                .cornerRadius(10)
                        }
                        .padding(.bottom, 10)
                        NavigationLink(destination: Register()) {
                            Text("Sign up")
                                .padding(10)
                                .font(.title2)
                                .background(Color.blue)
                                .foregroundStyle(.white)
                                .cornerRadius(10)
                        }
                    }
                    .padding(.top, 20)
                    .padding(.bottom, 30)
                }
            }
        }
    }
    // Home Screen Content
    struct HomeScreen: View {
        var body: some View {
            Text("Welcome!")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("✨Here are some random stuff✨")
                .italic()
                .font(.title2)
                .foregroundStyle(.black)
        }
    }
    
    // List of Artists
    struct ListScreen: View {
        let items: [String] = ["Nqrse", "Mafumafu", "Soraru", "Amatsuki"]
        
        var body: some View {
            VStack {
                HStack{
                    Text("Artist Name").bold().font(.title)
                        .multilineTextAlignment(.leading)
                    Image("singer") // Assuming you have an image named "singer" in the asset catalog
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .padding(.top, 20)
                }
                
                List(items, id: \.self) { name in
                    NavigationLink(destination: DetailScreen(itemName: name)) {
                        Text(name) // Display each name in the list
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
            }
        }
    }
    
// Detail Screen displaying artist information
struct DetailScreen: View {
let itemName: String

// Details for each artist
let artistDetails: [String: String] = [
"Nqrse": "Nqrse is a popular Japanese singer known for his energetic performances and powerful vocals.",
"Mafumafu": "Mafumafu is a talented producer and vocalist, known for his emotional voice and music compositions.",
"Soraru": "Soraru is a famous vocalist who is part of the popular YouTube collaboration group 'Aimer & Soraru'.",
"Amatsuki": "Amatsuki is known for his soft voice and covers of anime songs, and he's a prominent figure in the Vocaloid community."
]

// Corresponding artist images in the asset catalog
let artistImages: [String: String] = [
"Nqrse": "nqrse", // Image names should match the name of the images in your asset catalog
"Mafumafu": "mafumafu",
"Soraru": "soraru",
"Amatsuki": "amatsuki"
]
@State private var isliked:Bool = false //state variable

var body: some View {
VStack {
    Text("\(itemName)")
        .font(.title)
        .bold()
        .padding(.top, 20)
    
    // Display artist image
    if let imageName = artistImages[itemName] {
        Image(imageName) // Display image using the name from the asset catalog
            .resizable()
            .scaledToFit()
            .frame(width: 300, height: 200)
            .padding(.top, 10)
    } else {
        Text("No image available.")
    }
    Spacer()
        .frame(height:20)
    // Display artist details
    Text(artistDetails[itemName] ?? "No details available.")
        .padding()
        .font(.title2)
        .multilineTextAlignment(.center)
}
// adding like button and heart
HStack  {
    Button(action: {
        isliked.toggle() // Toggle the like state
    }) {
        Text(isliked ? "Unlike" : "Like") // Change text depending on isLiked state
            .frame(width: 80, height: 40)
            .padding()
            .font(.title3)
            .foregroundStyle(.white)
            .background(isliked ? Color.green : Color.gray)
            .cornerRadius(10)
    }
    
    Image(systemName: isliked ? "heart.fill" : "heart") // Heart icon that toggles
        .foregroundStyle(Color.pink)
        .scaledToFit()
        .padding(15)
}
.padding(.top, 10)
}
}
// Click Tracker structure
struct ClickTracker: View {
// create state variable 'count'
@State private var count = 0

@State private var isbuttonDisabled = true
// create a function that return a colorbased on the value of count
func getColor(for count: Int) -> Color {
switch count {
case 0:
    return .gray
case Int.min..<0: // less than 0
    return .red
case 1...5:
    return .green
case 6...10:
    return .blue
default:
    return .purple
}
}

var body: some View {
ZStack {
    Color.blue.opacity(0.2)
    
    VStack(spacing : 30) {
        Text("Click Tracker: \(count)")
            .font(.largeTitle)
            .padding([.top, .bottom], 50)
            .padding([.leading, .trailing], 30)
            .foregroundStyle(.white)
            .background(getColor(for: count))
        HStack (spacing: 30){
            Button("Decrease") {
                count -= 1
            }
            .padding()
            .background(Color.red)
            .foregroundStyle(.white)
            Button("Increase") {
                count += 1
            }
            .padding()
            .background(Color.green)
            .foregroundStyle(.white)
            
            
        }
        Button("Reset") {
            count = 0
            
        }
        .padding()
        .background(Color.blue)
        .foregroundStyle(.white)
        .disabled(isbuttonDisabled)
        .padding()
        // disable the buttons
        Button(action: {
            isbuttonDisabled.toggle()
        })
        {
        Text("\(isbuttonDisabled ? "Disable" : "Enable") button")
              .foregroundColor(isbuttonDisabled ? .red : .green) // Change text color based on state
              .padding()
              .bold()
              .cornerRadius(10)
        }
    }
}
}
}
    struct Register: View {
        @State private var username = ""
        @State private var email = ""
        @State private var isValid = false
        @State private var password = ""
        @State private var confirmpassword = ""
        
        // email validation
        func isEmailValid(_ email: String) -> Bool {
            return email.contains("@") && email.contains(".")
        }
        func passwordMatch() -> Bool {
            return password == confirmpassword
        }
        var body: some View {
            Form {
                TextField("Your username", text: $username)
                    .textInputAutocapitalization(.never)
                Section{
                    TextField("Your email", text: $email)
                        .textInputAutocapitalization(.never)
                        .onChange(of: email) {
                            isValid = isEmailValid(email)
                        } // can use isEmpty to check is field is empty
                    
                    Text("\(isValid ? "valid email" : "invalid email")")
                        .italic()
                        .font(.caption)
                        .foregroundStyle(isValid ? .green : .red)
                }
                // password section
                Section{
                    TextField("Your password", text: $password)
                    
                    //confirmation password
                    TextField("Re enter your password", text: $confirmpassword)
                    
                    // Password match validation message
                Text("\(passwordMatch() ? "Passwords match" : "Passwords don't match")")
                    .italic()
                    .font(.caption)
                    .foregroundStyle(passwordMatch() ? .green : .red)
                    .padding(.top, 5)
                }
                // button is outside of the form
                Button(action : {
                    print("Registration sucessful!")
                }) {
                    Text("Register")
                }
                .padding()
                .frame(maxWidth: .infinity)
                .foregroundStyle(.white)
                .background(isValid && !username.isEmpty ? .green: .gray)
                .disabled(isValid && !username.isEmpty ? false:true)
                .cornerRadius(20)
                
            }
            
        }
    }
}

#Preview {
    ContentView()
}
