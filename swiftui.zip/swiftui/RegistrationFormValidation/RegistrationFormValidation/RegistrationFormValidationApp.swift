//
//  RegistrationFormValidationApp.swift
//  RegistrationFormValidation
//
//  Created by Students on 5/3/25.
//

import SwiftUI

@main
struct RegistrationFormValidationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
