//
//  ContentView.swift
//  RegistrationFormValidation
//
//  Created by Students on 5/3/25.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    @State private var email = ""
    @State private var isValid = false

    
    func isEmailValid(_ email: String) -> Bool {
        return email.contains("@") && email.contains(".")
    }
    var body: some View {
        Form {
            TextField("Your username", text: $username)
                .textInputAutocapitalization(.never)
            Section{
                TextField("Your email", text: $email)
                    .textInputAutocapitalization(.never)
                    .onChange(of: email) {
                        isValid = isEmailValid(email)
                    } // can use isEmpty to check is field is empty
                
                Text("\(isValid ? "valid email" : "invalid email")")
                    .italic()
                    .font(.caption)
                    .foregroundStyle(isValid ? .green : .red)
            }
            // button is outside of the form
            Button(action : {
                print("Registration sucessful!")
            }) {
                Text("Register")
            }
            .padding()
            .frame(maxWidth: .infinity)
            .foregroundStyle(.white)
            .background(isValid && !username.isEmpty ? .green: .gray)
            .disabled(isValid && !username.isEmpty ? false:true)
            .cornerRadius(20)
            
            //Text("Form submited!")
        }
       
    }
}

#Preview {
    ContentView()
}
