//
//  TicTacToeApp.swift
//  TicTacToe
//
//  Created by Students on 5/3/25.
//

import SwiftUI

@main
struct TicTacToeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
