//
//  ContentView.swift
//  ProfileCard
//
//  Created by Students on 3/3/25.
//
// func is like a method has formatname() that is use to call it out in order for it to execute. Define func: func formatName(fn:s, ln=s) print(fn,ln)
// ... 3 dot is indicate the range, eg, 0...9

import SwiftUI


struct ContentView: View { // struct is like a template

    var body: some View {
        Card(firstname: "Jane", jobtitle: "Developer") // specify value for firstname property
        Divider() // add a divider line
        Card(firstname: "Jack", jobtitle: "Web designer")
    }
}

#Preview {
    ContentView()
}
struct Card: View {
    
    var firstname: String
    var jobtitle: String
    
    // define function here
    func formatName(prefix: String, firstName: String, lastName: String) -> String {
        // return a formatted name starting with prefix, caapitalising both name
        return "\(prefix). \(firstName.uppercased()) \(lastName.uppercased())"
    }
        
    var body: some View {
        ZStack {
//            .fill(RadialGradient(colors:[.green.opacity(0.2), .blue.opacity(0.3)],
//                                 center: .center,
//                                startRadius: 0,
//                                endRadius: 300))
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(colors:[.yellow.opacity(0.3),.green.opacity(0.5)],
                                     startPoint: .top, endPoint: .bottom))
                .opacity(0.4)
                .frame(width:300, height: 350)
            VStack {
                Image(systemName: "person.crop.circle.fill")
                // make image resizable
                    .resizable()
                // scale image to fit
                    .scaledToFit()
                // set image to 100 by 100
                    .frame(width:100, height:100)
                // set color to blue
                    .imageScale(.large)
                    .foregroundStyle(.blue)
                // Text for name
                Text(formatName(prefix: "Ms", firstName: firstname, lastName: "Lee"))
                    .font(.title)
                    .bold()
                // text for job title
                Text(jobtitle)
                    .bold()
                    .font(.subheadline)
                    .foregroundStyle(.purple)
                HStack {
                    // social icons1
                    Image("tik-tok")
                        .resizable()
                        .scaledToFit()
                    // social icon2
                    Image("instagram")
                        .resizable()
                        .scaledToFit()
                    // social icon3
                    Image("facebook")
                        .resizable()
                        .scaledToFit()
                    
                    
                }
                .frame(width:100, height:80)
            }
            .padding()
        }
    }
}

