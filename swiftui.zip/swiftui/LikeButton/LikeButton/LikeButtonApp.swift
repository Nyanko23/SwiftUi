//
//  LikeButtonApp.swift
//  LikeButton
//
//  Created by Students on 4/3/25.
//

import SwiftUI

@main
struct LikeButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
