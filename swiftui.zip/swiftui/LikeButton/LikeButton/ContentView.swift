//
//  ContentView.swift
//  LikeButton
//
//  Created by Students on 4/3/25.
//

import SwiftUI

struct ContentView: View {
    @State private var numOfTimes = 0
    @State private var isLiked: Bool = false
    @State private var isLiked2: Bool = false

    var body: some View {
        VStack {
            Button("Press me") {
                numOfTimes += 1
            }
            .padding()
            .background(Color.purple)
            .foregroundColor(.white)
            .fontWeight(.bold)
            .font(.title)
            // button text
            Text("button tapped \(numOfTimes) times")
                .font(.title3)
                .padding(20)
            
        }
        .padding(50)
        // add like button
        HStack{
            Button(action:  {isLiked.toggle()}) { // action parameter
                //toggle
                Text(isLiked ? "Unlike" : "Like") // label for button
                    .frame(width:80, height: 60)
                    .padding()
                    .font(.title)
                    .foregroundStyle(.white)
                    .background(isLiked ? Color.green: Color.gray)
                
            }
            Image(systemName: isLiked ? "heart.fill": "heart").foregroundStyle(Color.pink)
                .scaledToFit()
            
                .padding(30)
        }
    }
}


#Preview {
    ContentView()
}
